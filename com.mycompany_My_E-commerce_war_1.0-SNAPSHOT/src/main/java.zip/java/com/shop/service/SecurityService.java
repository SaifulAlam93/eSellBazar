///*
// * To change this license header, choose License Headers in Project Properties.
// * To change this template file, choose Tools | Templates
// * and open the template in the editor.
// */
//package com.shop.service;
//
//
////import dao.UserDao;
////import model.SystemUser;
//import com.shop.model.Users;
//import com.shop.repository.RepositoryImp;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
///**
// *
// * @author User
// */
//@Service
//public class SecurityService {
//
//    @Autowired
//    RepositoryImp  repository;
//
//    public Users getUserByIdAndPasswordFromDB(String userEmail) {
//
//        Users systemUser = repository.getUserByIdAndPasswordFromDB(userEmail);
//
//        return systemUser;
//    }
//
//}
